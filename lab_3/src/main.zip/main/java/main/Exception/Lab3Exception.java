package main.Exception;

public class Lab3Exception extends Exception {
    public Lab3Exception(String s) {
        super(s);
    }
}
