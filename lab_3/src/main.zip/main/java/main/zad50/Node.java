package main.zad50;

public class Node {
    public String val;
    public Node left;
    public Node right;

    public Node(String val) {
        this.val = val;
    }
}
